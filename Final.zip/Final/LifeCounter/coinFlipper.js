function coinFlipper(){
  this.side='Heads';
	this.display=function(){
  	ellipse(300,300,150,150);
    textAlign(CENTER,CENTER);
    textSize(50);
    text(this.side,300,300);
  }
  	this.flip=function mouseClicked() {
    if(random(0,1) < 0.5){
      this.side = 'Heads';
    } else {
      this.side = 'Tails';
    }
  }
}