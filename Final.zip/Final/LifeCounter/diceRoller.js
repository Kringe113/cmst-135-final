function diceRoller(sixDie,twelveDie,twentyDie){
  this.display=function(){
    this.sixDie=sixDie
    this.twelveDie=twelveDie
    this.twentyDie=twentyDie
    push();
  	rect(50,250,100,100);
    triangle(215,350,265,250,315,350);
    ellipse(400,300,100,100);
    textAlign(CENTER,CENTER);
    text(this.sixDie,100,300);
    text(this.twelveDie,265,315);
    text(this.twentyDie,400,300);
    pop();
  }
  
  this.roll=function(){
  if(mouseIsPressed){
  if(mouseX>0 && mouseX<600 && mouseY>0 && mouseY<600){
  this.sixDie=random(1,6);
     // this.twelveDie=random(1,12);
      //this.twentyDie=random(1,20);
}}}}