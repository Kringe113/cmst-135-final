
var LC;
var CF;
var DR;
var stage=[0,1,2];

function setup() { 
  createCanvas(600,600);
  LC=new lifeCounter();
  CF=new coinFlipper();
  DR=new diceRoller(6,12,20);
  stage=0
} 

function draw() { 
background(0);
rect(500,275,100,50);
rect(500,325,100,50);
rect(500,225,100,50);
textAlign(CENTER,CENTER);
  push();
textSize(12);
text('LifeCounter',550,300);
text('CoinFlipper',550,350);
text('DiceRoller',550,250);
  pop();
  

if(stage==0){
	LC.display();
  LC.lifeCounterButtons();
}else if(stage==1){
   CF.display();
   CF.flip();
}else if(stage==2){
  DR.display();
}
} 


function mouseClicked(){
//if (mouseIsPressed){
if(mouseX>500 && mouseX<600 && mouseY>275 && mouseY<325){
  stage=[0]
}
if(mouseX>500 && mouseX<600 && mouseY>325 && mouseY<375){
  stage=[1]
}
if(mouseX>500 && mouseX<600 && mouseY>225 && mouseY<275){
  stage=[2]
}
}