function lifeCounter() {
  this.L=20
  this.L2=20
  
  this.display=function(){
  //push();
  ellipse(300,400,150,150);
  textAlign(CENTER,CENTER);
  textSize(50);
  text(this.L,300,400);

  rect(175,550,100,50);
  text("+1",225,575);
  
  rect(300,550,100,50);
  text("-1",350,575);
  
  rect(425,550,100,50);
  text("-5",475,575);
  
  rect(50,550,100,50);
  text("+5",100,575);
  
  ellipse(300,200,150,150);
  text(this.L2,300,200);

  rect(175,0,100,50);
  text("+1",225,25);
  
  rect(300,0,100,50);
  text("-1",350,25);
  
  rect(425,0,100,50);
  text("-5",475,25);
  
  rect(50,0,100,50);
  text("+5",100,25);
  //  pop();
  }

this.lifeCounterButtons=function(){
  if(mouseIsPressed){
  if(mouseX>175 && mouseX<275 && mouseY>550 && mouseY<600){
  this.L=this.L+1
  }
  if(mouseX>300 && mouseX<400 && mouseY>550 && mouseY<600){
  this.L=this.L-1
  }
  if(mouseX>425 && mouseX<525 && mouseY>550 && mouseY<600){
  this.L=this.L-5
  }
  if(mouseX>50 && mouseX<150 && mouseY>550 && mouseY<600){
  this.L=this.L+5
  }
  if(mouseX>175 && mouseX<275 && mouseY>50 && mouseY<0){
  this.L2=this.L2+1
  }
  if(mouseX>175 && mouseX<275 && mouseY>0 && mouseY<50){
  this.L2=this.L2+1
  }
  if(mouseX>300 && mouseX<400 && mouseY>0 && mouseY<50){
  this.L2=this.L2-1
  }
  if(mouseX>425 && mouseX<525 && mouseY>0 && mouseY<50){
  this.L2=this.L2-5
  }
  if(mouseX>50 && mouseX<150 && mouseY>0 && mouseY<50){
  this.L2=this.L2+5
 	 		}
  	}
	}
}
